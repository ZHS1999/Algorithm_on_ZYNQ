// ==============================================================
// File generated on Sun Apr 21 21:04:37 +0800 2024
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2018.3 (64-bit)
// SW Build 2405991 on Thu Dec  6 23:38:27 MST 2018
// IP Build 2404404 on Fri Dec  7 01:43:56 MST 2018
// Copyright 1986-2018 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XDETECTION_ACC_H
#define XDETECTION_ACC_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xdetection_acc_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
#else
typedef struct {
    u16 DeviceId;
    u32 Crtl_bus_BaseAddress;
} XDetection_acc_Config;
#endif

typedef struct {
    u32 Crtl_bus_BaseAddress;
    u32 IsReady;
} XDetection_acc;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XDetection_acc_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XDetection_acc_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XDetection_acc_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XDetection_acc_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XDetection_acc_Initialize(XDetection_acc *InstancePtr, u16 DeviceId);
XDetection_acc_Config* XDetection_acc_LookupConfig(u16 DeviceId);
int XDetection_acc_CfgInitialize(XDetection_acc *InstancePtr, XDetection_acc_Config *ConfigPtr);
#else
int XDetection_acc_Initialize(XDetection_acc *InstancePtr, const char* InstanceName);
int XDetection_acc_Release(XDetection_acc *InstancePtr);
#endif

void XDetection_acc_Start(XDetection_acc *InstancePtr);
u32 XDetection_acc_IsDone(XDetection_acc *InstancePtr);
u32 XDetection_acc_IsIdle(XDetection_acc *InstancePtr);
u32 XDetection_acc_IsReady(XDetection_acc *InstancePtr);
void XDetection_acc_EnableAutoRestart(XDetection_acc *InstancePtr);
void XDetection_acc_DisableAutoRestart(XDetection_acc *InstancePtr);

void XDetection_acc_Set_Input_offset(XDetection_acc *InstancePtr, u32 Data);
u32 XDetection_acc_Get_Input_offset(XDetection_acc *InstancePtr);
void XDetection_acc_Set_Output_offset(XDetection_acc *InstancePtr, u32 Data);
u32 XDetection_acc_Get_Output_offset(XDetection_acc *InstancePtr);
void XDetection_acc_Set_Weight_offset(XDetection_acc *InstancePtr, u32 Data);
u32 XDetection_acc_Get_Weight_offset(XDetection_acc *InstancePtr);
void XDetection_acc_Set_Beta_offset(XDetection_acc *InstancePtr, u32 Data);
u32 XDetection_acc_Get_Beta_offset(XDetection_acc *InstancePtr);
void XDetection_acc_Set_InFM_num(XDetection_acc *InstancePtr, u32 Data);
u32 XDetection_acc_Get_InFM_num(XDetection_acc *InstancePtr);
void XDetection_acc_Set_OutFM_num(XDetection_acc *InstancePtr, u32 Data);
u32 XDetection_acc_Get_OutFM_num(XDetection_acc *InstancePtr);
void XDetection_acc_Set_Kernel_size(XDetection_acc *InstancePtr, u32 Data);
u32 XDetection_acc_Get_Kernel_size(XDetection_acc *InstancePtr);
void XDetection_acc_Set_Kernel_stride(XDetection_acc *InstancePtr, u32 Data);
u32 XDetection_acc_Get_Kernel_stride(XDetection_acc *InstancePtr);
void XDetection_acc_Set_TM(XDetection_acc *InstancePtr, u32 Data);
u32 XDetection_acc_Get_TM(XDetection_acc *InstancePtr);
void XDetection_acc_Set_TN(XDetection_acc *InstancePtr, u32 Data);
u32 XDetection_acc_Get_TN(XDetection_acc *InstancePtr);
void XDetection_acc_Set_TR(XDetection_acc *InstancePtr, u32 Data);
u32 XDetection_acc_Get_TR(XDetection_acc *InstancePtr);
void XDetection_acc_Set_TC(XDetection_acc *InstancePtr, u32 Data);
u32 XDetection_acc_Get_TC(XDetection_acc *InstancePtr);
void XDetection_acc_Set_mLoops(XDetection_acc *InstancePtr, u32 Data);
u32 XDetection_acc_Get_mLoops(XDetection_acc *InstancePtr);
void XDetection_acc_Set_nLoops(XDetection_acc *InstancePtr, u32 Data);
u32 XDetection_acc_Get_nLoops(XDetection_acc *InstancePtr);
void XDetection_acc_Set_LayerType(XDetection_acc *InstancePtr, u32 Data);
u32 XDetection_acc_Get_LayerType(XDetection_acc *InstancePtr);
void XDetection_acc_Set_M(XDetection_acc *InstancePtr, u32 Data);
u32 XDetection_acc_Get_M(XDetection_acc *InstancePtr);

void XDetection_acc_InterruptGlobalEnable(XDetection_acc *InstancePtr);
void XDetection_acc_InterruptGlobalDisable(XDetection_acc *InstancePtr);
void XDetection_acc_InterruptEnable(XDetection_acc *InstancePtr, u32 Mask);
void XDetection_acc_InterruptDisable(XDetection_acc *InstancePtr, u32 Mask);
void XDetection_acc_InterruptClear(XDetection_acc *InstancePtr, u32 Mask);
u32 XDetection_acc_InterruptGetEnabled(XDetection_acc *InstancePtr);
u32 XDetection_acc_InterruptGetStatus(XDetection_acc *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
