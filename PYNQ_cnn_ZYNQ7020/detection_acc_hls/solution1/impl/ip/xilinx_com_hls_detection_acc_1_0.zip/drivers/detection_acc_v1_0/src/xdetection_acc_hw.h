// ==============================================================
// File generated on Sun Apr 21 21:04:37 +0800 2024
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2018.3 (64-bit)
// SW Build 2405991 on Thu Dec  6 23:38:27 MST 2018
// IP Build 2404404 on Fri Dec  7 01:43:56 MST 2018
// Copyright 1986-2018 Xilinx, Inc. All Rights Reserved.
// ==============================================================
// CRTL_BUS
// 0x00 : Control signals
//        bit 0  - ap_start (Read/Write/COH)
//        bit 1  - ap_done (Read/COR)
//        bit 2  - ap_idle (Read)
//        bit 3  - ap_ready (Read)
//        bit 7  - auto_restart (Read/Write)
//        others - reserved
// 0x04 : Global Interrupt Enable Register
//        bit 0  - Global Interrupt Enable (Read/Write)
//        others - reserved
// 0x08 : IP Interrupt Enable Register (Read/Write)
//        bit 0  - Channel 0 (ap_done)
//        bit 1  - Channel 1 (ap_ready)
//        others - reserved
// 0x0c : IP Interrupt Status Register (Read/TOW)
//        bit 0  - Channel 0 (ap_done)
//        bit 1  - Channel 1 (ap_ready)
//        others - reserved
// 0x10 : Data signal of Input_offset
//        bit 31~0 - Input_offset[31:0] (Read/Write)
// 0x14 : reserved
// 0x18 : Data signal of Output_offset
//        bit 31~0 - Output_offset[31:0] (Read/Write)
// 0x1c : reserved
// 0x20 : Data signal of Weight_offset
//        bit 31~0 - Weight_offset[31:0] (Read/Write)
// 0x24 : reserved
// 0x28 : Data signal of Beta_offset
//        bit 31~0 - Beta_offset[31:0] (Read/Write)
// 0x2c : reserved
// 0x30 : Data signal of InFM_num
//        bit 31~0 - InFM_num[31:0] (Read/Write)
// 0x34 : reserved
// 0x38 : Data signal of OutFM_num
//        bit 31~0 - OutFM_num[31:0] (Read/Write)
// 0x3c : reserved
// 0x40 : Data signal of Kernel_size
//        bit 31~0 - Kernel_size[31:0] (Read/Write)
// 0x44 : reserved
// 0x48 : Data signal of Kernel_stride
//        bit 31~0 - Kernel_stride[31:0] (Read/Write)
// 0x4c : reserved
// 0x50 : Data signal of TM
//        bit 31~0 - TM[31:0] (Read/Write)
// 0x54 : reserved
// 0x58 : Data signal of TN
//        bit 31~0 - TN[31:0] (Read/Write)
// 0x5c : reserved
// 0x60 : Data signal of TR
//        bit 31~0 - TR[31:0] (Read/Write)
// 0x64 : reserved
// 0x68 : Data signal of TC
//        bit 31~0 - TC[31:0] (Read/Write)
// 0x6c : reserved
// 0x70 : Data signal of mLoops
//        bit 31~0 - mLoops[31:0] (Read/Write)
// 0x74 : reserved
// 0x78 : Data signal of nLoops
//        bit 31~0 - nLoops[31:0] (Read/Write)
// 0x7c : reserved
// 0x80 : Data signal of LayerType
//        bit 31~0 - LayerType[31:0] (Read/Write)
// 0x84 : reserved
// 0x88 : Data signal of M
//        bit 31~0 - M[31:0] (Read/Write)
// 0x8c : reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XDETECTION_ACC_CRTL_BUS_ADDR_AP_CTRL            0x00
#define XDETECTION_ACC_CRTL_BUS_ADDR_GIE                0x04
#define XDETECTION_ACC_CRTL_BUS_ADDR_IER                0x08
#define XDETECTION_ACC_CRTL_BUS_ADDR_ISR                0x0c
#define XDETECTION_ACC_CRTL_BUS_ADDR_INPUT_OFFSET_DATA  0x10
#define XDETECTION_ACC_CRTL_BUS_BITS_INPUT_OFFSET_DATA  32
#define XDETECTION_ACC_CRTL_BUS_ADDR_OUTPUT_OFFSET_DATA 0x18
#define XDETECTION_ACC_CRTL_BUS_BITS_OUTPUT_OFFSET_DATA 32
#define XDETECTION_ACC_CRTL_BUS_ADDR_WEIGHT_OFFSET_DATA 0x20
#define XDETECTION_ACC_CRTL_BUS_BITS_WEIGHT_OFFSET_DATA 32
#define XDETECTION_ACC_CRTL_BUS_ADDR_BETA_OFFSET_DATA   0x28
#define XDETECTION_ACC_CRTL_BUS_BITS_BETA_OFFSET_DATA   32
#define XDETECTION_ACC_CRTL_BUS_ADDR_INFM_NUM_DATA      0x30
#define XDETECTION_ACC_CRTL_BUS_BITS_INFM_NUM_DATA      32
#define XDETECTION_ACC_CRTL_BUS_ADDR_OUTFM_NUM_DATA     0x38
#define XDETECTION_ACC_CRTL_BUS_BITS_OUTFM_NUM_DATA     32
#define XDETECTION_ACC_CRTL_BUS_ADDR_KERNEL_SIZE_DATA   0x40
#define XDETECTION_ACC_CRTL_BUS_BITS_KERNEL_SIZE_DATA   32
#define XDETECTION_ACC_CRTL_BUS_ADDR_KERNEL_STRIDE_DATA 0x48
#define XDETECTION_ACC_CRTL_BUS_BITS_KERNEL_STRIDE_DATA 32
#define XDETECTION_ACC_CRTL_BUS_ADDR_TM_DATA            0x50
#define XDETECTION_ACC_CRTL_BUS_BITS_TM_DATA            32
#define XDETECTION_ACC_CRTL_BUS_ADDR_TN_DATA            0x58
#define XDETECTION_ACC_CRTL_BUS_BITS_TN_DATA            32
#define XDETECTION_ACC_CRTL_BUS_ADDR_TR_DATA            0x60
#define XDETECTION_ACC_CRTL_BUS_BITS_TR_DATA            32
#define XDETECTION_ACC_CRTL_BUS_ADDR_TC_DATA            0x68
#define XDETECTION_ACC_CRTL_BUS_BITS_TC_DATA            32
#define XDETECTION_ACC_CRTL_BUS_ADDR_MLOOPS_DATA        0x70
#define XDETECTION_ACC_CRTL_BUS_BITS_MLOOPS_DATA        32
#define XDETECTION_ACC_CRTL_BUS_ADDR_NLOOPS_DATA        0x78
#define XDETECTION_ACC_CRTL_BUS_BITS_NLOOPS_DATA        32
#define XDETECTION_ACC_CRTL_BUS_ADDR_LAYERTYPE_DATA     0x80
#define XDETECTION_ACC_CRTL_BUS_BITS_LAYERTYPE_DATA     32
#define XDETECTION_ACC_CRTL_BUS_ADDR_M_DATA             0x88
#define XDETECTION_ACC_CRTL_BUS_BITS_M_DATA             32

