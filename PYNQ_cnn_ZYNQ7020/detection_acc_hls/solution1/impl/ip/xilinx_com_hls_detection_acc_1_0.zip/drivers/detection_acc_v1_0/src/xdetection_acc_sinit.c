// ==============================================================
// File generated on Sun Apr 21 21:04:37 +0800 2024
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2018.3 (64-bit)
// SW Build 2405991 on Thu Dec  6 23:38:27 MST 2018
// IP Build 2404404 on Fri Dec  7 01:43:56 MST 2018
// Copyright 1986-2018 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#include "xparameters.h"
#include "xdetection_acc.h"

extern XDetection_acc_Config XDetection_acc_ConfigTable[];

XDetection_acc_Config *XDetection_acc_LookupConfig(u16 DeviceId) {
	XDetection_acc_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XDETECTION_ACC_NUM_INSTANCES; Index++) {
		if (XDetection_acc_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XDetection_acc_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XDetection_acc_Initialize(XDetection_acc *InstancePtr, u16 DeviceId) {
	XDetection_acc_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XDetection_acc_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XDetection_acc_CfgInitialize(InstancePtr, ConfigPtr);
}

#endif

