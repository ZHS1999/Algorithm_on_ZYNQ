// ==============================================================
// File generated on Sun Apr 21 21:04:37 +0800 2024
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2018.3 (64-bit)
// SW Build 2405991 on Thu Dec  6 23:38:27 MST 2018
// IP Build 2404404 on Fri Dec  7 01:43:56 MST 2018
// Copyright 1986-2018 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xdetection_acc.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XDetection_acc_CfgInitialize(XDetection_acc *InstancePtr, XDetection_acc_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Crtl_bus_BaseAddress = ConfigPtr->Crtl_bus_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XDetection_acc_Start(XDetection_acc *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDetection_acc_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XDETECTION_ACC_CRTL_BUS_ADDR_AP_CTRL) & 0x80;
    XDetection_acc_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XDETECTION_ACC_CRTL_BUS_ADDR_AP_CTRL, Data | 0x01);
}

u32 XDetection_acc_IsDone(XDetection_acc *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDetection_acc_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XDETECTION_ACC_CRTL_BUS_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XDetection_acc_IsIdle(XDetection_acc *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDetection_acc_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XDETECTION_ACC_CRTL_BUS_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XDetection_acc_IsReady(XDetection_acc *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDetection_acc_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XDETECTION_ACC_CRTL_BUS_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XDetection_acc_EnableAutoRestart(XDetection_acc *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDetection_acc_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XDETECTION_ACC_CRTL_BUS_ADDR_AP_CTRL, 0x80);
}

void XDetection_acc_DisableAutoRestart(XDetection_acc *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDetection_acc_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XDETECTION_ACC_CRTL_BUS_ADDR_AP_CTRL, 0);
}

void XDetection_acc_Set_Input_offset(XDetection_acc *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDetection_acc_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XDETECTION_ACC_CRTL_BUS_ADDR_INPUT_OFFSET_DATA, Data);
}

u32 XDetection_acc_Get_Input_offset(XDetection_acc *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDetection_acc_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XDETECTION_ACC_CRTL_BUS_ADDR_INPUT_OFFSET_DATA);
    return Data;
}

void XDetection_acc_Set_Output_offset(XDetection_acc *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDetection_acc_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XDETECTION_ACC_CRTL_BUS_ADDR_OUTPUT_OFFSET_DATA, Data);
}

u32 XDetection_acc_Get_Output_offset(XDetection_acc *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDetection_acc_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XDETECTION_ACC_CRTL_BUS_ADDR_OUTPUT_OFFSET_DATA);
    return Data;
}

void XDetection_acc_Set_Weight_offset(XDetection_acc *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDetection_acc_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XDETECTION_ACC_CRTL_BUS_ADDR_WEIGHT_OFFSET_DATA, Data);
}

u32 XDetection_acc_Get_Weight_offset(XDetection_acc *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDetection_acc_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XDETECTION_ACC_CRTL_BUS_ADDR_WEIGHT_OFFSET_DATA);
    return Data;
}

void XDetection_acc_Set_Beta_offset(XDetection_acc *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDetection_acc_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XDETECTION_ACC_CRTL_BUS_ADDR_BETA_OFFSET_DATA, Data);
}

u32 XDetection_acc_Get_Beta_offset(XDetection_acc *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDetection_acc_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XDETECTION_ACC_CRTL_BUS_ADDR_BETA_OFFSET_DATA);
    return Data;
}

void XDetection_acc_Set_InFM_num(XDetection_acc *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDetection_acc_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XDETECTION_ACC_CRTL_BUS_ADDR_INFM_NUM_DATA, Data);
}

u32 XDetection_acc_Get_InFM_num(XDetection_acc *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDetection_acc_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XDETECTION_ACC_CRTL_BUS_ADDR_INFM_NUM_DATA);
    return Data;
}

void XDetection_acc_Set_OutFM_num(XDetection_acc *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDetection_acc_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XDETECTION_ACC_CRTL_BUS_ADDR_OUTFM_NUM_DATA, Data);
}

u32 XDetection_acc_Get_OutFM_num(XDetection_acc *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDetection_acc_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XDETECTION_ACC_CRTL_BUS_ADDR_OUTFM_NUM_DATA);
    return Data;
}

void XDetection_acc_Set_Kernel_size(XDetection_acc *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDetection_acc_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XDETECTION_ACC_CRTL_BUS_ADDR_KERNEL_SIZE_DATA, Data);
}

u32 XDetection_acc_Get_Kernel_size(XDetection_acc *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDetection_acc_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XDETECTION_ACC_CRTL_BUS_ADDR_KERNEL_SIZE_DATA);
    return Data;
}

void XDetection_acc_Set_Kernel_stride(XDetection_acc *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDetection_acc_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XDETECTION_ACC_CRTL_BUS_ADDR_KERNEL_STRIDE_DATA, Data);
}

u32 XDetection_acc_Get_Kernel_stride(XDetection_acc *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDetection_acc_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XDETECTION_ACC_CRTL_BUS_ADDR_KERNEL_STRIDE_DATA);
    return Data;
}

void XDetection_acc_Set_TM(XDetection_acc *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDetection_acc_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XDETECTION_ACC_CRTL_BUS_ADDR_TM_DATA, Data);
}

u32 XDetection_acc_Get_TM(XDetection_acc *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDetection_acc_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XDETECTION_ACC_CRTL_BUS_ADDR_TM_DATA);
    return Data;
}

void XDetection_acc_Set_TN(XDetection_acc *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDetection_acc_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XDETECTION_ACC_CRTL_BUS_ADDR_TN_DATA, Data);
}

u32 XDetection_acc_Get_TN(XDetection_acc *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDetection_acc_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XDETECTION_ACC_CRTL_BUS_ADDR_TN_DATA);
    return Data;
}

void XDetection_acc_Set_TR(XDetection_acc *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDetection_acc_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XDETECTION_ACC_CRTL_BUS_ADDR_TR_DATA, Data);
}

u32 XDetection_acc_Get_TR(XDetection_acc *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDetection_acc_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XDETECTION_ACC_CRTL_BUS_ADDR_TR_DATA);
    return Data;
}

void XDetection_acc_Set_TC(XDetection_acc *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDetection_acc_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XDETECTION_ACC_CRTL_BUS_ADDR_TC_DATA, Data);
}

u32 XDetection_acc_Get_TC(XDetection_acc *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDetection_acc_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XDETECTION_ACC_CRTL_BUS_ADDR_TC_DATA);
    return Data;
}

void XDetection_acc_Set_mLoops(XDetection_acc *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDetection_acc_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XDETECTION_ACC_CRTL_BUS_ADDR_MLOOPS_DATA, Data);
}

u32 XDetection_acc_Get_mLoops(XDetection_acc *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDetection_acc_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XDETECTION_ACC_CRTL_BUS_ADDR_MLOOPS_DATA);
    return Data;
}

void XDetection_acc_Set_nLoops(XDetection_acc *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDetection_acc_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XDETECTION_ACC_CRTL_BUS_ADDR_NLOOPS_DATA, Data);
}

u32 XDetection_acc_Get_nLoops(XDetection_acc *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDetection_acc_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XDETECTION_ACC_CRTL_BUS_ADDR_NLOOPS_DATA);
    return Data;
}

void XDetection_acc_Set_LayerType(XDetection_acc *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDetection_acc_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XDETECTION_ACC_CRTL_BUS_ADDR_LAYERTYPE_DATA, Data);
}

u32 XDetection_acc_Get_LayerType(XDetection_acc *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDetection_acc_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XDETECTION_ACC_CRTL_BUS_ADDR_LAYERTYPE_DATA);
    return Data;
}

void XDetection_acc_Set_M(XDetection_acc *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDetection_acc_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XDETECTION_ACC_CRTL_BUS_ADDR_M_DATA, Data);
}

u32 XDetection_acc_Get_M(XDetection_acc *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDetection_acc_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XDETECTION_ACC_CRTL_BUS_ADDR_M_DATA);
    return Data;
}

void XDetection_acc_InterruptGlobalEnable(XDetection_acc *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDetection_acc_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XDETECTION_ACC_CRTL_BUS_ADDR_GIE, 1);
}

void XDetection_acc_InterruptGlobalDisable(XDetection_acc *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDetection_acc_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XDETECTION_ACC_CRTL_BUS_ADDR_GIE, 0);
}

void XDetection_acc_InterruptEnable(XDetection_acc *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XDetection_acc_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XDETECTION_ACC_CRTL_BUS_ADDR_IER);
    XDetection_acc_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XDETECTION_ACC_CRTL_BUS_ADDR_IER, Register | Mask);
}

void XDetection_acc_InterruptDisable(XDetection_acc *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XDetection_acc_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XDETECTION_ACC_CRTL_BUS_ADDR_IER);
    XDetection_acc_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XDETECTION_ACC_CRTL_BUS_ADDR_IER, Register & (~Mask));
}

void XDetection_acc_InterruptClear(XDetection_acc *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDetection_acc_WriteReg(InstancePtr->Crtl_bus_BaseAddress, XDETECTION_ACC_CRTL_BUS_ADDR_ISR, Mask);
}

u32 XDetection_acc_InterruptGetEnabled(XDetection_acc *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XDetection_acc_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XDETECTION_ACC_CRTL_BUS_ADDR_IER);
}

u32 XDetection_acc_InterruptGetStatus(XDetection_acc *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XDetection_acc_ReadReg(InstancePtr->Crtl_bus_BaseAddress, XDETECTION_ACC_CRTL_BUS_ADDR_ISR);
}

